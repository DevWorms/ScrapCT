<!DOCTYPE html>
<html>
<head>
	<title>Pagina no encontrada</title>
	<link href="https://fonts.googleapis.com/css?family=Bree+Serif|Work+Sans" rel="stylesheet"> 
</head>
<body>
	<style type="text/css">
		.cuerpo{
			width: 50%;
			margin: 5% auto;
			font-family: 'Work Sans', sans-serif;
		}
	</style>
	<h1 class="cuerpo">
		Lo sentimos
		<br>
		Error: 404 Página no encontrada :(
	</h1>
</body>
</html>