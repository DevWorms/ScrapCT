<div class="col-md-3 menu colorSecundario cuerpo">
	<nav>
		<ul>
		    <li>
		    	<a href="amazon">
		    		<img src="img/ic_amazon.png">
		    		Proceso Amazon
		    	</a>
		    </li>
		    <li>
		    	<a href="usuarios">
		    		<img src="img/ic_user.png">
		    		Agregar Usuario
		    	</a>
		    </li>
		    <li>
		    	<a href="scrapping">
		    		<img src="img/ic_scrapping.png">
		    		Scraping URL's
		    	</a>
		    </li>
		    <li>
		    	<a href="precios">
		    		<img src="img/price-tag.png">
		    		Scraping Precio's
		    	</a>
		    </li>
		    <li>
		    	<a href="obtener-excel">
		    		<img src="img/ic_excel.png">
		    		Obtener Excel

		    	</a>
		    </li>
		    <li>
		    	<a href="custom-post">
		    		<img src="img/form.png">
		    		Custom Post
		    	</a>
		    </li>
		  </ul>
	</nav>
</div>

